package firstbot.robots.buildings;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Laboratory extends Building {
  public Laboratory(RobotController rc) throws GameActionException {
    super(rc);
  }

  @Override
  protected void runTurn() throws GameActionException {

  }
}
