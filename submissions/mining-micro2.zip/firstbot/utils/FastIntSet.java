package firstbot.utils;

public class FastIntSet {
}
